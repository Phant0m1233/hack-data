import tkinter as tk
from tkinter import ttk, scrolledtext
from PIL import Image, ImageTk
import cv2
import threading
import serial.tools.list_ports
import serial
import subprocess  # Import subprocess module for executing external script

class SerialReaderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Drone Surveillance System")

        # Get screen width and height
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()

        # Set window size to 80% of the screen width and height
        self.window_width = int(0.8 * screen_width)
        self.window_height = int(0.8 * screen_height)

        # Center the window on the screen
        x_position = (screen_width - self.window_width) // 2
        y_position = (screen_height - self.window_height) // 2

        self.root.geometry(f"{self.window_width}x{self.window_height}+{x_position}+{y_position}")
        self.root.config(bg='#2C2C2C')  # Dark background color

        self.serialObj = serial.Serial()
        self.ports = [str(port) for port in serial.tools.list_ports.comports()]

        self.is_reading = False
        self.cap = None  # OpenCV VideoCapture object
        self.video_thread = None  # Thread for capturing video frames

        self.create_widgets()

    def create_widgets(self):
        style = ttk.Style()

        # Styling for Buttons
        style.configure("TButton", padding=6, relief="flat", background="#4CAF50", foreground="black")

        # Styling for Labels
        style.configure("TLabel", foreground="white", background='#2C2C2C')

        # Styling for Taskbar buttons
        style.configure("Taskbar.TButton", foreground="black", background="#4CAF50")

        # Header
        header_label = tk.Label(self.root, text="Drone Surveillance System", font=('Arial', 24, 'bold'), bg='#333333', fg='white', pady=15)
        header_label.grid(row=0, column=0, columnspan=2, sticky='nsew')

        # Quadrant 1: Buttons
        buttons_frame = ttk.Frame(self.root, padding=(20, 20), style="TFrame")
        buttons_frame.grid(row=1, column=0, sticky='nsew')

        com_label = ttk.Label(buttons_frame, text="Select COM Port:", font=('Arial', 14), style="TLabel")
        com_label.grid(row=0, column=0, pady=10, sticky='w')

        self.combo_var = tk.StringVar()
        com_combobox = ttk.Combobox(buttons_frame, textvariable=self.combo_var, values=self.ports, state='readonly', font=('Arial', 12))
        com_combobox.grid(row=0, column=1, pady=10)

        connect_button = ttk.Button(buttons_frame, text="Connect", command=self.connect_port, style="TButton")
        connect_button.grid(row=0, column=2, pady=10)

        self.start_button = ttk.Button(buttons_frame, text="Start Reading", command=self.start_reading, style="TButton")
        self.start_button.grid(row=1, column=0, padx=10)

        self.stop_button = ttk.Button(buttons_frame, text="Stop Reading", command=self.stop_reading, style="TButton")
        self.stop_button.grid(row=2, column=0, padx=10)
        self.stop_button.state(['disabled'])  # Initially disabled

        start_camera_button = ttk.Button(buttons_frame, text="Start Camera", command=self.open_camera, style="TButton")
        start_camera_button.grid(row=1, column=2, padx=10)

        stop_camera_button = ttk.Button(buttons_frame, text="Stop Camera", command=self.close_camera, style="TButton")
        stop_camera_button.grid(row=2, column=2, padx=10)

        # Quadrant 2: Coaxial Image
        coaxial_frame = ttk.Frame(self.root, padding=(20, 20), style="TFrame")
        coaxial_frame.grid(row=2, column=0, sticky='nsew')

        coaxial_image_path = "Coaxial.jpg"  # Replace with the actual path to your image
        coaxial_img = Image.open(coaxial_image_path)
        coaxial_img = coaxial_img.resize((int(self.window_width * 0.2), int(self.window_height * 0.2)))
        coaxial_img = ImageTk.PhotoImage(coaxial_img)

        coaxial_label = tk.Label(coaxial_frame, image=coaxial_img)
        coaxial_label.image = coaxial_img  # Reference to keep image from being garbage collected
        coaxial_label.pack(fill=tk.BOTH, expand=True)

        # Quadrant 3: Reading Box
        data_frame = ttk.Frame(self.root, padding=(20, 20), style="TFrame")
        data_frame.grid(row=1, column=1, rowspan=2, sticky='nsew')

        self.data_text = scrolledtext.ScrolledText(data_frame, width=40, height=20, wrap='none', bg='#333333', fg='white', font=('Courier New', 11))
        self.data_text.pack(fill=tk.BOTH, expand=True)

        # Quadrant 4: Live Camera Feed
        live_camera_frame = ttk.Frame(self.root, padding=(20, 20), style="TFrame")
        live_camera_frame.grid(row=1, column=1, sticky='nsew')

        self.camera_label = tk.Label(live_camera_frame, bg='#333333')
        self.camera_label.pack(fill=tk.BOTH, expand=True)

        # Taskbar
        taskbar_frame = ttk.Frame(self.root, style="TFrame")
        taskbar_frame.grid(row=3, column=0, columnspan=2, sticky='nsew')

        control_room_button = ttk.Button(taskbar_frame, text="Control Room", command=self.show_control_room, style="Taskbar.TButton")
        control_room_button.grid(row=0, column=0, padx=10)

        ground_station_button = ttk.Button(taskbar_frame, text="Ground Station", command=self.show_ground_station, style="Taskbar.TButton")
        ground_station_button.grid(row=0, column=1, padx=10)

        coaxial_drone_button = ttk.Button(taskbar_frame, text="Coaxial Drone", command=self.show_coaxial_drone, style="Taskbar.TButton")
        coaxial_drone_button.grid(row=0, column=2, padx=10)

        task_force_button = ttk.Button(taskbar_frame, text="Task Force", command=self.show_task_force, style="Taskbar.TButton")
        task_force_button.grid(row=0, column=3, padx=10)

        # Quadrant weights for resizing
        self.root.grid_rowconfigure(1, weight=1)
        self.root.grid_rowconfigure(2, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_columnconfigure(1, weight=1)

        # Handle window close event
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def connect_port(self):
        selected_port = self.combo_var.get()
        if selected_port:
            com_port_var = str(selected_port.split(' ')[0])
            print(com_port_var)
            self.serialObj.port = com_port_var
            self.serialObj.baudrate = 9600
            self.serialObj.open()

    def start_reading(self):
        if not self.is_reading:
            self.is_reading = True
            self.start_button.state(['disabled'])
            self.stop_button.state(['!disabled'])
            self.check_serial_port()

    def stop_reading(self):
        if self.is_reading:
            self.is_reading = False
            self.start_button.state(['!disabled'])
            self.stop_button.state(['disabled'])

    def check_serial_port(self):
        if self.is_reading and self.serialObj.isOpen() and self.serialObj.in_waiting:
            recent_packet = self.serialObj.readline()
            recent_packet_string = recent_packet.decode('utf').rstrip('\n')
            self.data_text.insert('end', recent_packet_string + '\n')
            self.data_text.yview('end')

        if self.is_reading:
            self.root.after(100, self.check_serial_port)

    def open_camera(self):
        if self.cap is None:
            self.cap = cv2.VideoCapture(1)  # Open the default camera (camera index 0)

            # Start a thread for capturing video frames
            self.video_thread = threading.Thread(target=self.show_camera, daemon=True)
            self.video_thread.start()

    def show_camera(self):
        while self.cap is not None and self.cap.isOpened():
            ret, frame = self.cap.read()
            if ret:
                # Convert the OpenCV frame to a PhotoImage
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(frame)
                img = ImageTk.PhotoImage(img)

                # Update the label with the new frame
                self.camera_label.config(image=img)
                self.camera_label.image = img

    def close_camera(self):
        if self.cap is not None:
            self.cap.release()
            self.cap = None

    def on_close(self):
        # Release resources and close the application
        if self.cap is not None:
            self.cap.release()
        self.root.destroy()

    def show_control_room(self):
        # Add code to switch to the Control Room page
        print("Switching to Control Room")

    def show_ground_station(self):
        # Add code to switch to the Ground Station page
        print("Switching to Ground Station")
        subprocess.run(["python", "GS.py"])  # Execute openGS.py script

    def show_coaxial_drone(self):
        # Add code to switch to the Coaxial Drone page
        print("Switching to Coaxial Drone")
        subprocess.run(["python", "coaxial.py"])  # Execute coaxial.py script

    def show_task_force(self):
        # Add code to switch to the Task Force page
        print("Switching to Task Force")
        subprocess.run(["python", "task_force.py"])  # Execute task_force.py script


if __name__ == "__main__":
    root = tk.Tk()
    app = SerialReaderApp(root)  # Replace with the actual main application class
    root.mainloop()
