import tkinter as tk
from tkinter import ttk, scrolledtext
from PIL import Image, ImageTk
import cv2
import threading
import serial.tools.list_ports
import serial

class BasePage(ttk.Frame):
    def __init__(self, master, serialObj):
        super().__init__(master)
        self.serialObj = serialObj
        self.ports = [str(port) for port in serial.tools.list_ports.comports()]
        self.create_widgets()

    def create_widgets(self):
        # This method will be overridden in the subclasses
        pass

class ControlRoomPage(BasePage):
    def create_widgets(self):
        # Your Control Room page widgets here

        # Add Quit button to close the page
        quit_button = ttk.Button(self, text="Quit", command=self.quit_page)
        quit_button.pack()

    def quit_page(self):
        # Perform any cleanup actions before quitting the page
        self.destroy()

class GroundStationPage(BasePage):
    def create_widgets(self):
        # Your Ground Station page widgets here
        style = ttk.Style()

        # Styling for Buttons
        style.configure("TButton", padding=6, relief="flat", background="#4CAF50", foreground="black")

        # Styling for Labels
        style.configure("TLabel", foreground="white", background='#2C2C2C')

        # Header
        header_label = tk.Label(self, text="Ground Station", font=('Arial', 24, 'bold'), bg='#333333', fg='white', pady=15)
        header_label.pack()

        # Quadrant 1: Buttons
        buttons_frame = ttk.Frame(self, padding=(20, 20), style="TFrame")
        buttons_frame.pack()

        com_label = ttk.Label(buttons_frame, text="Select COM Port:", font=('Arial', 14), style="TLabel")
        com_label.grid(row=0, column=0, pady=10, sticky='w')

        self.combo_var = tk.StringVar()
        com_combobox = ttk.Combobox(buttons_frame, textvariable=self.combo_var, values=self.ports, state='readonly', font=('Arial', 12))
        com_combobox.grid(row=0, column=1, pady=10)

        connect_button = ttk.Button(buttons_frame, text="Connect", command=self.connect_port, style="TButton")
        connect_button.grid(row=0, column=2, pady=10)

        self.start_button = ttk.Button(buttons_frame, text="Start Reading", command=self.start_reading, style="TButton")
        self.start_button.grid(row=1, column=0, padx=10)

        self.stop_button = ttk.Button(buttons_frame, text="Stop Reading", command=self.stop_reading, style="TButton")
        self.stop_button.grid(row=2, column=0, padx=10)
        self.stop_button.state(['disabled'])  # Initially disabled

        # Quadrant 3: Reading Box
        data_frame = ttk.Frame(self, padding=(20, 20), style="TFrame")
        data_frame.pack()

        self.data_text = scrolledtext.ScrolledText(data_frame, width=40, height=20, wrap='none', bg='#333333', fg='white', font=('Courier New', 11))
        self.data_text.pack(fill=tk.BOTH, expand=True)

        # Add Quit button to close the page
        quit_button = ttk.Button(self, text="Quit", command=self.quit_page)
        quit_button.pack()

    def connect_port(self):
        selected_port = self.combo_var.get()
        if selected_port:
            com_port_var = str(selected_port.split(' ')[0])
            print(com_port_var)
            self.serialObj.port = com_port_var
            self.serialObj.baudrate = 9600
            self.serialObj.open()

    def start_reading(self):
        # Your start_reading logic here
        pass

    def stop_reading(self):
        # Your stop_reading logic here
        pass

    def quit_page(self):
        # Perform any cleanup actions before quitting the page
        self.destroy()
        self.master.destroy()  # Close the current page and the main application window

# ... Repeat similar changes for CoaxialDronePage and TaskForcePage ...

if __name__ == "__main__":
    root = tk.Tk()
    ground_station_page = GroundStationPage(root, serial.Serial())
    ground_station_page.pack(fill=tk.BOTH, expand=True)
    root.mainloop()
